import arcpy
from arcpy import da
import os
from shutil import copyfile



## USAGE INSTRUCTIONS ###

#### Create Script Tool In Pro ####
#In ArcGS Pro use the included script tool or create one from the parameters


##Create output folder for photos####
# Make a single windows folder in your project. I called mine 'out' but you can call it whatever you like.
# This is where the photos will be initially be placed. The tool will also create subfolders in this folder
# based on your sortfield and make additioanal copies of the photos in these subfolders when it runs.


### Why create this tool the tool useful?###
# 1. It puts all the photos into a folder.
# There is a github script that does this but it creates poor files names and loses a connection to the attributes. I used this code in the functions.
# Source = https://support.esri.com/en/technical-article/000011912

# 2. It creates a table with all the collected attributes and a field that matches the photo filename.

# 3. The sorting is useful. You might want to sort the photos into subfolders by the 'Creator' field.

# 4. You can create a custom file name for the photos based off your attributes.

# 5. It adds geometry fields to your table in Decimal Degrees.



###### What does the tool create? #####

#IT DOES NOT CREATE  any new tables or featureclasses in your project. In fact, the only thing you have in your project
#is the script tool and the original geodatabase of points and attachments.

#It adds the following fields to your attachment table:
#   - X and Y decimal degrees fields to your table, called POINT_X and POINT_Y.
#   - Copies of the unique ID fields called FeatureID and AttachID that are created by the tool.
#     (In the source data these are used as objectID and could change if the data was copied.)
#   - It can copies all the (default survey123) fields and other fields from the point collection featureclass into the attach table.
#     (If you are using survey123 these fields are: Creator, Editor, CreationDate, EditDate)
#   - It copies any additional custom fields you are using, such as Category and Description or Type or Name or anything else

#It add the following fields to your point featureclass:
#   - It adds a featureID field, which is the same as the objectID, this is a unique field
#   - It adds POINT_X, POINT_Y, and POINT_Z fields (if there is a z)

#It creates the following output files:
#   - In your output folder it places all the photos that were collected.
#   - It names the photos based on the fields in the code:
#   - It makes subfolders based on a field and then copies the photos into these subfolders


####Requirements#######


#####TO CLEAN UP AND RUN FOR THE FIRST TIME#####
#-rmove the contents of the output folder, but leave that folder there and empty
#-Remove all the new fields added in the attachment table (all the fields after the data field, starting with AttachID all theway to PhotName). KEEP THE DATA FIELD!!!)
#-remove the FeatureID, POINT_X, POINT_Y, and POINT_Z fields in the MyPoints (point) fc



##Run the script tool###

#PARAMS: (when entering in the script tool omit the quotes)
#features =  featureclass, collected gdb featureclass you downloaded from AGOL/Portal
#attachments =  table, collected attachment gdb table you downloaded from AGOL/Portal
#outfolder = folder, 'output' folder you need to have this empty and alteady there. Phtotos go there
#sortfield = field or string, the sort field, ie  'CATEGORY' or 'Creator' for example.
#  This field must also be present below in the userifields
#localkey = string, 'GlobalID'  the local field name in the features that joines to the same value in the attachment
#foreignkey = string, 'REL_GLOBALID' the foreign key field name in the attachment table that matches the features id
#userfields = existing fields to include from the featureclass, in this format 'CATEGORY;DESCRIPTION;CreationDate;Creator;EditDate;Editor;Picture'  
#photoprefacefield =  the field name used ot preface the photo filname (ie 'Creator' field name) so the photos are then named Creator_FeatureID_AttachID.jpg for instance.
#  This field must also be present below in the userifields



#################################################################

############## FUNCTIONS #########

#### sortsfiles into subfolders based on a field 
def sortphotos_function(attachtable2, outfolder3, sortfield1, photoprefacefield1):

  print('\n Sorting started using as the sort field ...')
  print('\n sortfield: ' + sortfield1)


  with da.SearchCursor(attachtable2, [photoprefacefield1, "FeatureID", "AttachID", sortfield1]) as cursor:
  # CATEGORY example - it must be used in this line below for either a custom sort field or if used in the field name syntax
  # with da.SearchCursor(attachtable2, ["FeatureID", "AttachID", "CATEGORY", "Creator"]) as cursor:

    for item in cursor:

  
      #construct the name of the photo file from the desired attributes. This line must match the similar one in
      # the 
      filename = str(item[0]) + '_' +  str(item[1]) + '_' +  str(item[2]) +'.jpg'  

      ## EDIT THE LINE BELOW TO POINT TO THE INDEX OF YOUR SORT FIELD, it must be one of the fields you are bringing in above
      subfolder = str(item[3]) #sortfield
      
      newsubfolder = outfolder3 + "/" + subfolder
      # make the category subfolder if it doesnt already exist
      if not os.path.exists(newsubfolder):
        os.makedirs(newsubfolder)
 
      orig_filefullpath = outfolder3 + "/" + filename
      dest_filefullpath = newsubfolder + "/" + filename
 
      copyfile(orig_filefullpath, dest_filefullpath)
        
      print('\n ... sorting complete.')
      print('\n' )



#### improves the attachment attribute table with fields from the features table
def improveattachmenttable_function(attachmenttable1, foreignkey1, features1, localkey1, userfields1):

  print('\n Improving attachment attribute table ... ')
  print("\n attachmenttable1: " + attachmenttable1 + '\n')
  print("\n foreignkey1: " + foreignkey1 + '\n')
  print("\n features1: " + features1 + '\n')
  print("\n localkey1: " + localkey1 + '\n')


  arcpy.env.transferDomains = True

 
  #preserve ids as new fields in both inputs
  arcpy.management.AddField(features1, "FeatureID", "LONG", None, None, None, None, "NULLABLE", "NON_REQUIRED", None)
  arcpy.management.CalculateField(features1, "FeatureID", "!OBJECTID!", "PYTHON", None)

  print("\n Added FeatureID field to features")

  #add additional XY fields in DD
  arcpy.env.outputCoordinateSystem = arcpy.SpatialReference("WGS 1984")
  arcpy.management.AddXY(features1)

  print("\n Added POINT_X {POINT_Y fields in DD to features")
  
  arcpy.management.AddField(attachmenttable1, "AttachID", "LONG", None, None, None, None, "NULLABLE", "NON_REQUIRED", None)
  arcpy.management.CalculateField(attachmenttable1, "AttachID", "!ATTACHMENTID!", "PYTHON", None)

  print("\n Added AttachID field to attachments")

  #survey123 fields = "CreationDate;Creator;EditDate;Editor;Picture"
  fieldsmadehere = "FeatureID;POINT_X;POINT_Y"
  #user fields = "CATEGORY;DESCRIPTION"
  allfields = fieldsmadehere + ";" + userfields # "CATEGORY;DESCRIPTION;CreationDate;Creator;EditDate;Editor;Picture;FeatureID;POINT_X;POINT_Y"

  #add fields to the table from the collected points - "CATEGORY;DESCRIPTION;CreationDate;Creator;EditDate;Editor;Picture;FeatureID;POINT_X;POINT_Y"
  arcpy.management.JoinField(attachmenttable1, foreignkey1, features1, localkey1, allfields )
  #arcpy.management.JoinField("Photo_Collection__ATTACH", "REL_GLOBALID", "Photo_Collection", "GlobalID", "CATEGORY;DESCRIPTION;CreationDate;Creator;EditDate;Editor;Picture;FeatureID")

  print("\n Joined/added  all fields from features to the attach table")


  print("\n Finished creating the table.")



#### improves the attachment attribute table with fields from the features table
def extractphotos_function(attachmenttable1, outfolder1, photoprefacefield1):


  print("\n Starting extracting photos to single folder named " + outfolder1)
  
  # use joined attributes to create a unique meaningful file jpg name
  with da.SearchCursor(attachmenttable1, ['DATA', photoprefacefield1, "FeatureID", "AttachID"]) as cursor:
    for item in cursor:
            
      attachment = item[0]
      filename = str(item[1]) + '_' +  str(item[2]) + '_' +  str(item[3]) + '.jpg'
      open(outfolder1 + os.sep + filename, 'wb').write(attachment.tobytes())

      #arcpy.management.CalculateField(attachmenttable1, "Photoname", filename, "PYTHON", None)
          
      del item
      del filename
      del attachment

  print("\n Finished extracting photos to single folder named " + outfolder1)


#calculate the photonamefield
def calculatephotonamefield_function(attachmenttable1, photoprefacefield1):

  print("\n Creating field to hold photoname in attachment table")
            
  #create new photoname field
  arcpy.management.AddField(attachmenttable1, "Photoname", "Text", None, None, None, None, "NULLABLE", "NON_REQUIRED", None)

  print("\n Calculating photo name field")

  with arcpy.da.UpdateCursor(attachmenttable1, [photoprefacefield1, "FeatureID", "AttachID", "Photoname"]) as cursor: 
        for row in cursor:

            filename = str(row[0]) + '_' +  str(row[1]) + '_' +  str(row[2]) + '.jpg'
    
            row[3] = filename
            cursor.updateRow(row)
      
  print("\n Finished calculating photoname field.")



def showvariables(var1,var2,var3):
  print("\n var1 ")
  print("\n var2 ")
  print("\n var3 ")


#####  VARIABLES


#PARAMS for script tool
features = arcpy.GetParameterAsText(0) #featureclass, input: collected gdb featureclass
attachments = arcpy.GetParameterAsText(1) #table,input: collected attachment gdb table
outfolder = arcpy.GetParameterAsText(2) #folder: 'output' folder - you need to have this empty and alteady there. Phtotos go there
sortfield = arcpy.GetParameterAsText(3) #field or string, input: the sort field, ie  'CATEGORY' or 'Creator' for example. This field must also be persent below
localkey = arcpy.GetParameterAsText(4) #string, input'GlobalID'  the local field in the features that joines tothe same value in the attachment
foreignkey = arcpy.GetParameterAsText(5) #'REL_GLOBALID' the foreign key field in the attachment table that matches the features id
userfields = arcpy.GetParameterAsText(6) # 'CATEGORY;DESCRIPTION;CreationDate;Creator;EditDate;Editor;Picture'  ie the fields you want to include
photoprefacefield = arcpy.GetParameterAsText(7) # the field  used ot rpeface the photos ie Creator so the photos are then named Creator_FeatureID_AttachID.jpg


########## RUN PROGRAM PORTION

#add lots of needed fields to the original attachment table
improveattachmenttable_function(attachments, foreignkey, features, localkey, userfields)

#extract photos into single folder
extractphotos_function(attachments, outfolder, photoprefacefield)

#sort photos into folders using the sortfield - if successful new subfolders are created in your photofolder and the photos are copied there
sortphotos_function(attachments, outfolder, sortfield, photoprefacefield)

#add and calculate the photonamefield in the attachments table
calculatephotonamefield_function(attachments, photoprefacefield)






